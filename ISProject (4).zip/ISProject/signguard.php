<?php
session_start();
include 'connect.php';
if (!isset($_SESSION['AdminID'])) {
  header("Location: adminlog.php");
  exit();
}

if (isset($_SESSION['success_message'])) {
    echo '<div class="form__message form__message--success">' . $_SESSION['success_message'] . '</div>';
    unset($_SESSION['success_message']);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signup"])) {
    // Process signup form
    $guard_id = $_POST["guardID"];
    $name = $_POST["guardname"];
    $password = $_POST["guardPass"];

    // Validate form fields
    $errors = array();

    if (empty($guard_id)) {
        $errors[] = "Guard ID is required";
    }

    if (empty($name)) {
        $errors[] = "Name is required";
    }

    if (empty($password)) {
        $errors[] = "Password is required";
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    if (empty($errors)) {
        // Check if the guard ID is already registered
        $check_sql = "SELECT * FROM security WHERE guard_id = '$guard_id'";
        $check_result = $conn->query($check_sql);

        if ($check_result && $check_result->num_rows > 0) {
            // Guard ID is already registered
            $errors[] = "Guard is already registered";
        } else {
            // Insert new guard into the database with hashed password
            $insert_sql = "INSERT INTO security (guard_id, name, password)
                VALUES ('$guard_id', '$name', '$hashedPassword')";

            if ($conn->query($insert_sql) === TRUE) {
                // Registration successful
                $_SESSION['success_message'] = "Guard Registered Successfully";

                // Redirect to the login page
                header("Location: signguard.php");
                exit();
            } else {
                // Error inserting guard
                $errors[] = "Error registering guard: " . $conn->error;
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminlog.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Register Security</title>
</head>
<body>
  <header>
    <nav class="heads2">
      <img src="pics/625-6259602_strathmore-university-hd-png-download-removebg-preview.png" alt="">
      <h1 class="text-center">Register New Security Guards</h1>
      <a href="security.php">Guards</a>
      <a href="admin.php">Students</a>
      <a href="adminout.php" id = "logout">Logout</a>
    </nav>
</header> 
<form id="createAccount" action=" " method="post">
      <h1 class="form__title">New Security Guard</h1>
      
      <?php if (!empty($errors)) : ?>
        <div class="form__message form__message--error">
            <?php foreach ($errors as $error) : ?>
                <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($success_message)) : ?>
        <div class="form__message form__message--success">
            <?php echo $success_message; ?>
        </div>
    <?php endif; ?>
  
      <div class="form__input-group">
        <input type="text" id="studentID" class="form__input" autofocus placeholder="Guard ID" name="guardID">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="text" id="userName" class="form__input" autofocus placeholder="Enter name" name="guardname">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="password" class="form__input" autofocus placeholder="Password" name="guardPass">
        <div class="form__input-error-message"></div>
      </div>
      <button class="form__button" type="submit" name="signup">Continue</button>
</body>
</html>