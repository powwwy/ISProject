<?php
session_start();
include 'connect.php';
if (!isset($_SESSION['AdminID'])) {
  header("Location: adminlog.php");
  exit();
}
// Function to handle unassigning the guard
function unassignGuard($conn, $guardID, $name) {
  echo "<script>
  if (confirm('Are you sure you want to unassign this guard?')) {
    // If the admin confirms, proceed with the unassigning action.
    window.location.href = 'security.php?unassignID=$guardID';
  } else {
    alert('Unassignment of Guard $guardID $name canceled.');
  }
</script>";
}

if (isset($_POST['unassignButton'])) {
  $guardID = $_POST['guardID'];
  $name = $_POST['guardName'];
  unassignGuard($conn, $guardID, $name);
}

if (isset($_GET['unassignID'])) {
  $guardID = $_GET['unassignID'];

  // Delete associated reports first
  $deleteReportsSql = "DELETE FROM reports WHERE guard_id = '$guardID'";
  $resultReports = mysqli_query($conn, $deleteReportsSql);

  if ($resultReports) {
    // If reports are successfully deleted, proceed to delete the guard
    $deleteGuardSql = "DELETE FROM security WHERE guard_id = '$guardID'";
    $resultGuard = mysqli_query($conn, $deleteGuardSql);

    if ($resultGuard) {
      echo "<script>
            alert('Guard with ID $guardID has been unassigned.');
            window.location.href = 'security.php'; // Redirect back to the guard page
          </script>";
    } else {
      echo "<script>
            alert('Failed to unassign guard with ID $guardID. Please try again.');
            window.location.href = 'security.php'; // Redirect back to the guard page
          </script>";
    }
  } else {
    echo "<script>
            alert('Failed to delete reports for guard with ID $guardID. Please try again.');
            window.location.href = 'security.php'; // Redirect back to the guard page
          </script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminlog.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Security Guards</title>
</head>
<body>
  <header>
    <nav class="heads2">
      <img src="pics/625-6259602_strathmore-university-hd-png-download-removebg-preview.png" alt="">
      <h1 class="text-center">On-Duty Guards</h1>
      <a href="security.php" class="active">Guards</a>
      <a href="signguard.php">Register Guards</a>
      <a href="admin.php">Students</a>
      <a href="daily.php">System Reports</a>
      <a href="adminout.php" id="logout">Logout</a>
    </nav>
  </header>
  
  <table class="table">
  <thead>
    <tr>
      <th scope="col"><strong>Guard ID</strong></th>
      <th scope="col"><strong>Name</strong></th>
      <th scope="col"><strong>Reports</strong></th>
      <th scope="col"><strong>Report Dates</strong></th>
      <th scope="col"><strong>Unassign</strong></th>
    </tr>
  </thead>
  <tbody>
<?php
// fetch the guard and report data
$sql = "SELECT s.guard_id, s.name, r.report, r.report_date, r.reportStud
        FROM security s
        LEFT JOIN reports r ON s.guard_id = r.guard_id /*return records from security table(left) and reports (right) table and joins the records */
        ORDER BY s.guard_id, r.reportStud, r.report_date";

$result = mysqli_query($conn, $sql);

if ($result) {
  $prevGuardID = null; // Initialize variables to track previous guard ID
  $reported = ""; // Variable to captue the reports
  $prevReportDates = ""; // Variable to capture the report dates

  while ($row = mysqli_fetch_assoc($result)) {
    $id = $row['guard_id'];
    $name = $row['name'];
    $studentID = $row['reportStud'];
    $report = $row['report'];
    $reportDate = $row['report_date']; //collecting from the tables 

    if ($id !== $prevGuardID) {
      // Output the previous guard's information if a new guard is encountered
      if ($prevGuardID !== null) {
        echo "<tr>
                <th scope='row'>$prevGuardID</th>
                <td>$prevName</td>
                <td>$reported<br></td>
                <td>$prevReportDates <br></td>
                <td>
                  <form action='' method='post'>
                    <input type='hidden' name='guardID' value='$prevGuardID'>
                    <input type='hidden' name='guardName' value='$prevName'>
                    <button type='submit' name='unassignButton' class='btn btn-danger'>Unassign</button>
                  </form>
                </td>
              </tr>";
      }

      // Reset variables for the new guard
      $reported = "";
      $prevGuardID = $id;
      $prevName = $name;
      $prevReportDates = "";
    }

    // Collect and group student IDs and reports
    $reported .= "$studentID: $report<br><br>";
    // Collect and group report dates
    $prevReportDates .= "$reportDate<br><br>";
  }

  // Output the last guard's information
  if ($prevGuardID !== null) {
    echo "<tr>
            <th scope='row'>$prevGuardID</th>
            <td>$prevName</td>
            <td>$reported</td>
            <td>$prevReportDates</td>
            <td>
              <form action='' method='post'>
                <input type='hidden' name='guardID' value='$prevGuardID'>
                <input type='hidden' name='guardName' value='$prevName'>
                <button type='submit' name='unassignButton' class='btn btn-danger'>Unassign</button>
              </form>
            </td>
          </tr>";
  }
}
?>

</tbody>
</table>
</body>
</html>
