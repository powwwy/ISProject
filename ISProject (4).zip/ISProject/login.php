<?php
session_start();
include 'connect.php';

// Check if the form is submitted for login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $student_id = $_POST["StudentID"];
    $password = $_POST["passWord"];

    // Validate form fields
    $errors = array();
    if (empty($student_id)) {
        $errors[] = "Student ID is required";
    }

    if (empty($password)) {
        $errors[] = "Password is required";
    }

    if (empty($errors)) {
        // Check if the user exists in the database
        $sql = "SELECT * FROM students WHERE student_id = '$student_id'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $storedPassword = $row["password"];

            // Verify the entered password against the stored hashed password
            if (password_verify($password, $storedPassword)) {
                // Password is correct
                // Store the student ID in the session
                $_SESSION["studentID"] = $row["student_id"];
                // Redirect to the landing page
                header("Location: profile.php");
                exit();
            } else {
                // Password is incorrect
                $errors[] = "Invalid student ID or password";
            }
        } else {
            // User does not exist
            $errors[] = "Invalid student ID or password";
        }
    }
}
elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signup"])) {
    // Process signup form
    $student_id = $_POST["studentID"];
    $name = $_POST["userName"];
    $email = $_POST["userEmail"];
    $course = $_POST["course"];
    $password = $_POST["passWord"];

    // Validate form fields
    $errors = array();

    if (empty($student_id)) {
        $errors[] = "Student ID is required";
    }

    if (empty($name)) {
        $errors[] = "Name is required";
    }

    if (empty($email)) {
        $errors[] = "Email is required";
    }

    if (empty($password)) {
        $errors[] = "Password is required";
    }

    // If there are no errors, proceed with further processing
    if (empty($errors)) {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        // Check if the email and id is already registered
        $check_sql = "SELECT * FROM students WHERE email = '$email'";
        $check_sql2 = "SELECT * FROM students WHERE student_id = '$student_id'";
        $check_result = $conn->query($check_sql);
        $check_result2 = $conn->query($check_sql2);

        if ($check_result && $check_result->num_rows > 0) {
            // Email is already registered
            $errors[] = "Email is already registered";
        } elseif ($check_result2 && $check_result2->num_rows > 0) {
            // Email is already registered
            $errors[] = "Student ID is already registered";
        } else {
            // Insert new user into the database with hashed password
            $insert_sql = "INSERT INTO students (student_id, name, email, course, password)
                VALUES ('$student_id', '$name', '$email', '$course' ,'$hashedPassword')";

            if ($conn->query($insert_sql) === TRUE) {
                // Registration successful
                // Redirect to the login page
                header("Location: login.php");
                exit();
            } else {
                // Error inserting user
                $errors[] = "Error registering user: " . $conn->error;
            }
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="stylesheet" href="login.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@500&display=swap" rel="stylesheet">
</head>
<body>
  <div class="heads">
    <img src="pics/logostrathmore.png" alt="">
    <h1 id="formTitle" class="form__title">Student Vehicle Registration</h1>
    <h1></h1>
    <h1></h1>
  </div>

  <div class="container">
    <form class="form" id="login" action="login.php" method="post" onsubmit="return validateLogin()">
      <h1>Login</h1>
  
      <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"]) && !empty($errors)) : ?>
        <div class="form__message form__message--error">
          <?php foreach ($errors as $error) : ?>
            <p><?php echo $error; ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>  
      
      <div class="form__input-group">
        <input type="text" class="form__input" autofocus placeholder="Student ID" name="StudentID">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="password" class="form__input" autofocus placeholder="Password" name="passWord">
        <div class="form__input-error-message"></div>
      </div>
      <button class="form__button" type="submit" name="login">Continue</button>
      <p class="form__text">
        <a class="form__link" href="#" id="linkCreateAccount">Don't have an account? Create account</a>
      </p>
    </form>

    <form class="form form--hidden" id="createAccount" method="post" onsubmit="return validateSignup();">
      <h1 class="form__title">Create Account</h1>
      
      <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signup"]) && !empty($errors)) : ?>
        <div class="form__message form__message--error">
          <?php foreach ($errors as $error) : ?>
            <p><?php echo $error; ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <div class="form__input-group">
        <input type="text" id="studentID" class="form__input" autofocus placeholder="Student ID" name="studentID">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="text" id="userName" class="form__input" autofocus placeholder="Enter name" name="userName">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="text" id="course" class="form__input" autofocus placeholder="Enter Course" name="course">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="email" class="form__input" autofocus id="userEmail" placeholder="Email Address" name="userEmail">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="password" class="form__input" autofocus placeholder="Password" name="passWord">
        <div class="form__input-error-message"></div>
      </div>
      <button class="form__button" type="submit" name="signup">Continue</button>
      <p class="form__text">
        <a class="form__link" href="./" id="linkLogin">Already have an account? Sign in</a>
      </p>
    </form>

    <script>
      function validateSignup() {

        //getting the variables 
        const studentIDInput = document.getElementById("studentID");
        const nameInput = document.getElementById("userName");
        const courseInput = document.getElementById("course");
        
       // remove whitespace
        const studentIDValue = studentIDInput.value.trim();
        const nameValue = nameInput.value.trim();
        const courseValue = courseInput.value.trim();

        //validations
        const numbers = /^[0-9]+$/;
        const name = /^[A-Za-z\s]+$/;
        const course = /^[A-Z]{2,4}$/;

        //checking the accuracy of validations and returning errors
        if (!numbers.test(studentIDValue)) {
          alert("Student ID should only contain numbers");
          return false;
        }

        if (!name.test(nameValue)) {
          alert("Name should only contain letters and spaces");
          return false;
        }

        if (!course.test(courseValue)) {
          alert("Course should be 2 to 4 capital letters");
          return false;
        }
        return true;
      }
    document.addEventListener("DOMContentLoaded", () => {
      const loginForm = document.querySelector("#login");
      const createAccountForm = document.querySelector("#createAccount");
      const formTitle = document.querySelector("#formTitle");
    
      document.querySelector("#linkCreateAccount").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.add("form--hidden");
        createAccountForm.classList.remove("form--hidden");
        formTitle.textContent = "Sign up ";
      });
    
      document.querySelector("#linkLogin").addEventListener("click", e => {
        e.preventDefault();
        createAccountForm.classList.add("form--hidden");
        loginForm.classList.remove("form--hidden");
        formTitle.textContent = "Login ";
      });
    });
  </script>
</body>
</html>