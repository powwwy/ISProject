<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['guardID'])) {
  header("Location: guardlog.php");
  exit();
}

$guardID = $_SESSION['guardID'];

// Retrieve a list of students with vehicles from the database
$sqlStudents = "SELECT student_id FROM students WHERE registeredCar IS NOT NULL";
$resultStudents = mysqli_query($conn, $sqlStudents);

$studentOptions = "";
while ($row = mysqli_fetch_assoc($resultStudents)) {
  $studentID = $row['student_id'];
  $studentOptions .= "<option value='$studentID'>$studentID</option>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $reportDate = $_POST['reportDate'];
  $reportDetails = $_POST['reportDetails'];
  $reportStud = $_POST['reportStud'];

  $sqlInsert = "INSERT INTO reports (guard_id, report, report_date, reportStud) VALUES ('$guardID', '$reportDetails', '$reportDate', '$reportStud')";
  $resultInsert = mysqli_query($conn, $sqlInsert);

  if ($resultInsert) {
    header("Location: guard.php");
    exit();
  } else {
    echo "Error: " . mysqli_error($conn);
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="guard.css">
    <title>Document</title>
</head>
<body>
    <header>
    <nav class="heads2">
      <img src="pics/logostrathmore.png" alt="">
      <a href="guard.php">Students</a>
</nav>
</header>

<div class="report-form">
    <h2>Report Uncompliant Student</h2>
    <form action="report.php" method="post">

      <label for="reportDate">Report Date:</label>
      <input type="date" id="reportDate" name="reportDate" required>

      <label for="reportStud">Student Being reported:</label>
      <select name="reportStud" id="reportStud" required>
        <option value="">Select a student</option>
        <?php echo $studentOptions; ?>
      </select>

      <label for="reportDetails">Report Details:</label>
      <textarea id="reportDetails" name="reportDetails" required></textarea>

      <button type="submit">Submit Report</button>
    </form>
  </div>
</body>
</html>
