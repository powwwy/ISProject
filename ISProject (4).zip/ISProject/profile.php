<?php
session_start();
include 'connect.php';

if (!isset($_SESSION["studentID"])) {
  // User is not logged in, redirect to the login page
  header("Location: login.php");
  exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["editing"])) {
    $editing = true;
}
// Fetch student details
$studentID = $_SESSION['studentID'];
$sql = "SELECT * FROM students WHERE student_id = '$studentID'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $studentData = $result->fetch_assoc();
    $access = $studentData['access_status']; // Save the current access status in a variable
    $warnings = $studentData['warnings'];
} else {
    // Redirect to login if student data is not found (just to be safe)
    header("Location: login.php");
    exit();
}

// Check if the access status has changed and show an alert if it has
if (isset($_SESSION['prevAccess']) && $_SESSION['prevAccess'] != $access) {
    echo '<script>alert("Your access status has been changed. Your new access status is ' . ($access == 1 ? 'Denied' : 'Granted') . '");</script>';
}

// Save the current access status in the session for future comparison
$_SESSION['prevAccess'] = $access;

// Handle form submissions for updating student details
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["updateStudent"])) {
    $newName = $_POST["newName"];
    $newEmail = $_POST["newEmail"];
    $newCourse = $_POST["newCourse"];
    $isDisabled = isset($_POST["isDisabled"]) ? 1 : 0;

    // Update student details in the database
    $updateSql = "UPDATE students SET name = '$newName', email = '$newEmail', course = '$newCourse', isDisabled = '$isDisabled' WHERE student_id = '$studentID'";
    if ($conn->query($updateSql) === TRUE) {
        // Update successful, reload the page to show changes
        header("Location: profile.php");
        exit();
    } else {
        $updateError = "Error updating student details: " . $conn->error;
    }
}

// Fetch vehicle owned by the student (there's only one vehicle per student)
$sql = "SELECT * FROM vehicles WHERE ownerID = '$studentID'";
$result = $conn->query($sql);
$vehicle = $result->fetch_assoc();
// Handle form submission for deleting vehicle
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["deleteVehicle"])) {
  // Fetch the vehicle ID associated with the student
  $getVehicleIDSql = "SELECT numberPlate FROM vehicles WHERE ownerID = '$studentID'";
  $result = $conn->query($getVehicleIDSql);

  if ($result && $result->num_rows > 0) {
      $row = $result->fetch_assoc();
      $vehicleID = $row['numberPlate'];

      // Delete the vehicle from the database
      $deleteVehicleSql = "DELETE FROM vehicles WHERE numberPlate = '$vehicleID'";
      if ($conn->query($deleteVehicleSql) === TRUE) {
          // Vehicle deletion successful, update the registeredCar column to NULL
          $updateStudentSql = "UPDATE students SET registeredCar = NULL WHERE student_id = '$studentID'";
          if ($conn->query($updateStudentSql) === TRUE) {
              // Deletion and update successful, reload the page to show changes
              header("Location: profile.php");
              exit();
          } else {
              $deleteVehicleError = "Error deleting vehicle: " . $conn->error;
          }
      } else {
          $deleteVehicleError = "Error deleting vehicle: " . $conn->error;
      }
  } else {
      $deleteVehicleError = "Error finding vehicle associated with the student.";
  }
}
// Handle form submissions for updating vehicle details
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["updateVehicle"])) {
    $newNumberPlate = $_POST["newNumberPlate"];
    $newMake = $_POST["newMake"];
    $newModel = $_POST["newModel"];
    $newColor = $_POST["newColor"];

    // Update vehicle details in the database
    $updateVehicleSql = "UPDATE vehicles SET numberPlate = '$newNumberPlate', make = '$newMake', model = '$newModel', color = '$newColor' WHERE ownerID = '$studentID'";
    if ($conn->query($updateVehicleSql) === TRUE) {
        // Update successful, reload the page to show changes
        header("Location: profile.php");
        exit();
    } else {
        $updateVehicleError = "Error updating vehicle details: " . $conn->error;
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile</title>
  <link rel="stylesheet" href="form.css">
  <style>
    body{
      font-size: 20px;
    }
    h1{
      text-align: center;
    }
    .aside{
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: start;
}
 .profile_up{
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: start;
}
.profi{
  display: flex;
    flex-direction: column;
}
.vehicle-details{
  margin-right: 30px;
  margin-left: 300px;

}
    .hidden {
      display: none;
    }
   .btn{
      margin-left: -670px;
      margin-top: 350px;
      font-size :17px;
    }
    .buttons{
      margin-top: 10px;
      display: flex;
      flex-direction: row-reverse;
      font-size :17px;
      justify-content: space-evenly;
    }
  </style>
</head>

<body>
  <header>
    <nav class="nav1">
      <img src="pics/625-6259602_strathmore-university-hd-png-download-removebg-preview.png" alt="">
      <h1>Student Profile</h1>
      <a href="guidelines.html">Registration Guidelines</a>
      <a href="form.php">Registration Form</a>
      <a href="profile.php" class = "active" >Personal Details</a>
      <a href="logout.php" id = "logout">Logout</a>
    </nav>
  </header>
  <div class="profile-container">
    <p style = "text-align: center;"><strong>*PLEASE READ GUIDELINES BEFORE REGISTERING A VEHICLE</strong></p>
    <?php if(isset($editing) && $editing) : ?>
      <!-- Display the profile form for editing -->
      <form class="profile-form" action="profile.php" method="post">
        <br>
        <h1>Edit your details</h1> 
        <div class="profile_up">
          <div class="profi">
          <h2>Your Details</h2>
          <div class="form-group">
            <label for="studentID">Student ID:</label>
            <input type="text" readonly id="studentID" name="studentID" value="<?php echo $studentData['student_id']; ?>">
          </div>
          <div class="form-group">
            <label for="newName">Name:</label>
            <input type="text" id="newName" name="newName" value="<?php echo $studentData['name']; ?>">
          </div>
          <div class="form-group">
            <label for="newEmail">Email:</label>
            <input type="email" id="newEmail" name="newEmail" value="<?php echo $studentData['email']; ?>">
          </div>
          <div class="form-group">
            <label for="newCourse">Course:</label>
            <input type="text" id="newCourse" name="newCourse" value="<?php echo $studentData['course']; ?>">
          </div>
          
          <div class="form-group">
            <label for="isDisabled">Are you disabled?: <br> (Checked = YES Unchecked = NO) :</label>
            <input type="checkbox" id="isDisabled" name="isDisabled" <?php echo $studentData['isDisabled'] ? 'checked' : ''; ?>>
          </div>
          <div class="form-group">

          </div>
        </div>
          <!-- Display vehicle details (if any) and form fields for editing -->
          <?php if (!empty($vehicle)) : ?> 
            <div class="vehicle-details">
            <h2>Your Vehicle</h2>
                <div class="form-group">
                    <label for="newNumberPlate">Number Plate:</label>
                    <input type="text" id="newNumberPlate" readonly name="newNumberPlate" value="<?php echo $vehicle['numberPlate']; ?>">
                </div>
                <div class="form-group">
                    <label for="newMake">Make:</label>
                    <input type="text" id="newMake" name="newMake" value="<?php echo $vehicle['make']; ?>">
                </div>
                <div class="form-group">
                    <label for="newModel">Model:</label>
                    <input type="text" id="newModel" name="newModel" value="<?php echo $vehicle['model']; ?>">
                </div>
                <div class="form-group">
                    <label for="newColor">Color:</label>
                    <input type="text" id="newColor" name="newColor" value="<?php echo $vehicle['color']; ?>">
                </div>
              </div>
            </div>
            <div class="buttons">
                <button type="submit" name="deleteVehicle" class= "button">Delete Vehicle</button>
                <?php if (isset($updateVehicleError)) : ?>
                    <p class="error"><?php echo $updateVehicleError; ?></p>
                <?php endif; ?>
                <?php if (isset($deleteVehicleError)) : ?>
                    <p class="error"><?php echo $deleteVehicleError; ?></p>
                <?php endif; ?>
            
          <?php else : ?>
            <p>No vehicle found.</p>
          <?php endif; ?>
          <button type="submit" name="submitVehicle" class="button2">Update Vehicle Details</button>
          <button type="submit" name="updateStudent" class="button2">Update Student Details</button>
          <input type="hidden" name="updateVehicle" value="1">

<!-- Update the name attribute for the submit button -->

          <?php if (isset($updateError)) : ?>
            <p class="error"><?php echo $updateError; ?></p>
          <?php endif; ?>
        </div>
        </div>
          </div>
      </form>
    <?php else : ?>
      <!-- Display the profile details (non-editing mode) -->
      <h1>Welcome, <?php echo $studentData['name']; ?>!</h1>
      <div class="aside">
      <div class="profile-details">
        <h2><strong>Student ID:</strong> <?php echo $studentData['student_id']; ?></h2>
        <p><strong>Name:</strong> <?php echo $studentData['name']; ?></p>
        <p><strong>Email:</strong> <?php echo $studentData['email']; ?></p>
        <p><strong>Course:</strong> <?php echo $studentData['course']; ?></p>
        <p><strong>Are you disabled?: </strong> <?php echo $studentData['isDisabled'] ? 'Yes' : 'No'; ?></p>
        <p><strong>Warnings:</strong> <?php echo $studentData['warnings']; ?></p>
        <p><strong>Access Status:</strong> <?php echo $access ? 'Denied' : 'Granted' ; ?></p>
      </div>
      <br>
      <?php if (!empty($vehicle)) : ?>
        <div class="vehicle-details">
          <h2>Your Vehicle</h2>
          <p><strong>Number Plate:</strong> <?php echo $vehicle['numberPlate']; ?></p>
          <p><strong>Make:</strong> <?php echo $vehicle['make']; ?></p>
          <p><strong>Model:</strong> <?php echo $vehicle['model']; ?></p>
          <p><strong>Color:</strong> <?php echo $vehicle['color']; ?></p>
        </div>
      <?php else : ?>
        <p>No vehicle found.</p>  
        <?php endif; ?>
      <!-- Button to switch to edit mode -->
      <form action="" method="post" >
        <input type="hidden" name="editing" value="1">
        <button type="submit" class = "btn">Edit Your Details</button>
      </form>
    <?php endif; ?>   
  </div>
  </div>
</body>
</html>
