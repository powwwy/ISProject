<?php
session_start();
include 'connect.php'; // Assuming you have the database connection code in connect.php

// Check if the guard is logged in (You may modify this as needed)
if (!isset($_SESSION['guardID'])) {
  header("Location: guardlog.php");
  exit();
}

// Get the guardID from the session
$guardID = $_SESSION['guardID'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Get the form data
  $reportDate = $_POST['reportDate'];
  $reportDetails = $_POST['reportDetails'];
  $guardID = $_SESSION['guardID']; // Assuming you have a form field for guardID in your HTML form.

  // Prepare and execute the query to insert the report into the database
  $sqlInsert = "INSERT INTO reports (guardID, report, report_date) VALUES ('$guardID', '$reportDetails', '$reportDate')";
  $resultInsert = mysqli_query($conn, $sqlInsert);

  if ($resultInsert) {
    // Report successfully inserted
    header("Location: guard.php");
    exit();
  } else {
    // Error occurred while inserting the report
    // You may add error handling here as needed
    echo "Error: " . mysqli_error($conn);
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="guard.css">
    <title>Document</title>
</head>
<body>
    <header>
    <nav class="heads2">
      <img src="pics/logostrathmore.png" alt="">
      <a href="guard.php">Students</a>
</nav>
</header>

<div class="report-form">
    <h2>Report Uncompliant Student</h2>
    <form action="report.php" method="post">

      <label for="reportDate">Report Date:</label>
      <input type="date" id="reportDate" name="reportDate" required>

      <label for="reportDetails">Report Details:</label>
      <textarea id="reportDetails" name="reportDetails" required></textarea>

      <button type="submit">Submit Report</button>
    </form>
  </div>
</body>
</html>
