<?php
session_start();
include 'connect.php';
if (!isset($_SESSION['AdminID'])) {
  header("Location: adminlog.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminlog.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Display Users</title>
</head>
<body>
<header>
    <nav class="heads2">
      <img src="pics/625-6259602_strathmore-university-hd-png-download-removebg-preview.png" alt="">
      <h1 class="text-center ">Registered Students</h1>
      <a href="security.php">Guards</a>
      <a href="admin.php" class ="active">Students</a>
      <a href="daily.php" >System Reports</a>
      <a href="adminout.php" id = "logout">Logout</a>
    </nav>
</header> 
<?php
$sql = "SELECT * FROM administrator Where admin_id = '$_SESSION[AdminID]'";
$result = mysqli_query($conn, $sql);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $name = $row['name'];
      }
    }
    ?>
    <h2>Welcome Admin, <?php echo $name?></h2>
    <div class="search-bar">
    <input type="text" id="searchInput" placeholder="Search by Student ID">
  </div>

  <script>
    // Function to filter the student IDs based on the search input
    function filterStudents() {
      const searchInputValue = document.getElementById("searchInput").value.trim().toLowerCase();
      const studentRows = document.querySelectorAll(".table tbody tr");

      studentRows.forEach(row => {
        const studentId = row.querySelector("th").textContent.toLowerCase();
        if (studentId.includes(searchInputValue)) {
          row.style.display = "table-row";
        } else {
          row.style.display = "none";
        }
      });
    }

    // Event listener for the search input
    document.getElementById("searchInput").addEventListener("input", filterStudents);
  </script>
    <table class="table">
        <thead>
          <tr>
            <th scope="col"><strong>Student ID</strong></th>
            <th scope="col"><strong>Name</strong></th>
            <th scope="col"><strong>Course</strong></th>
            <th scope="col"><strong>Vehicle</strong></th>
            <th scope="col"><strong>Warnings</strong></th>
            <th scope="col"><strong>Access Status</strong></th>
            <th scope="col"><strong>Update Status</strong></th>
          </tr>
        </thead>
        <tbody>
        <?php
$sql = "SELECT * FROM students";
$result = mysqli_query($conn, $sql);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $id = $row['student_id'];
        $name = $row['name'];
        $course = $row['course'];
        $warnings = $row['warnings'];
        $car = $row['registeredCar'];
        $access = $row['access_status'];

        // Display "Granted" for access_status = 1, and "Denied" for access_status = 0
        $accessStatusDisplay = ($access == 0) ? "Granted" : "Denied";

        echo "<tr>
                <th scope='row'>$id</th>
                <td>$name</td>
                <td>$course</td>
                <td>$car</td>
                <td>$warnings</td>
                <td>Access $accessStatusDisplay</td>
                <td><button><a name='update' href='update.php?updateid={$row['student_id']}'>Update</button></td>
              </tr>";
    }
}
?>
        </tbody>
      </table>
</body>
</html>

 
