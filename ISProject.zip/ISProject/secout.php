<?php
include 'connect.php';
session_unset();
session_destroy();
header("Location: guardlog.php");
exit();
$conn->close();
?>