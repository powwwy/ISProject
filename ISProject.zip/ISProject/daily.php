<?php
// Database configuration
include 'connect.php'; 

// Query to retrieve data from the database
$sql_students = "SELECT COUNT(*) AS total_students FROM students";
$sql_vehicles = "SELECT COUNT(*) AS total_vehicles FROM vehicles";
$sql_guards = "SELECT COUNT(*) AS total_guards FROM security";
$sql_violators = "SELECT COUNT(*) AS total_violators FROM students WHERE access_status = 1";
$sql_reports = "SELECT COUNT(*) AS total_reports FROM reports";


// Function to execute the query and fetch the result
function fetchData($conn, $sql, $column) {
    $result = $conn->query($sql);
    if ($result) {
        $data = $result->fetch_assoc();
        return $data[$column] ?? 0;
    } else {
        echo "Error executing query: " . $conn->error;
        return 0;
    }
}

// Calculate totals by fetching data from the database
$total_students = fetchData($conn, $sql_students, 'total_students');
$total_vehicles = fetchData($conn, $sql_vehicles, 'total_vehicles');
$total_guards = fetchData($conn, $sql_guards, 'total_guards');
$total_violators = fetchData($conn, $sql_violators, 'total_violators');
$total_reports = fetchData($conn, $sql_reports, 'total_reports');

// Close the database connection
$conn
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reports</title>
  <link rel="stylesheet" href="adminlog.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <style>
    .table thead, th,td{
        font-size: 27px;
        text-align: center;
    }
  </style>
</head>
<body>
<header>
    <nav class="heads2">
      <img src="pics/625-6259602_strathmore-university-hd-png-download-removebg-preview.png" alt="">
      <h1 class="text-center">Student Vehicle Registration System Reports</h1>
      <a href="security.php">Guards</a>
      <a href="admin.php">Students</a>
      <a href="daily.php" class="active">System Reports</a>
      <a href="adminout.php" id="logout">Logout</a>
    </nav>
</header> 
  <div class="container mt-4">
  <table class="table">
        <thead>
          <tr>
            <th scope="col" style = "font-size:24px; font-weight: bold;">Registered Students</th>
            <th scope="col" style = "font-size:24px; font-weight: bold;">Registered Vehicles</th>
            <th scope="col" style = "font-size:24px; font-weight: bold;">Registered Security</th>
            <th scope="col"style = "font-size:24px; font-weight: bold;">Denied Students</th>
            <th scope="col" style = "font-size:24px; font-weight: bold;">Reports from Guards</th>
          </tr>
          <?php
          echo "<tr>
                <th scope='row'>$total_students</th>
                <td>$total_vehicles</td>
                <td>$total_guards</td>
                <td>$total_violators</td>
                <td>$total_reports</td>
              </tr>";
              ?>
        </thead>
        <tbody>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>