<?php
session_start();
include 'connect.php';
if (!isset($_SESSION["studentID"])) {
    // User is not logged in, redirect to the login page
    header("Location: login.php");
    exit();
  }
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process registration form
    $numberPlate = $_POST["numberPlate"];
    $isDisabled = $_POST["isDisabled"] === "true" ? 1 : 0;
    $studentID = $_SESSION['studentID'];
    $carMake = $_POST['carMake'];
    $carModel = $_POST['carModel'];
    $carColor = $_POST['carColor'];

    // Validate form fields
    $errors = array();

    if (empty($numberPlate)) {
        $errors[] = "Number Plate is required";
    }

    // Check if the number plate is valid
    // (Add your validation logic here)

    // If there are no errors, proceed with further processing
    if (empty($errors)) {
        // Start a transaction
        $conn->begin_transaction();

        // Check if the student has already registered a vehicle
        $checkRegisteredCarSql = "SELECT registeredCar FROM students WHERE student_id = '$studentID'";
        $result = $conn->query($checkRegisteredCarSql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $registeredCar = $row['registeredCar'];

            if (!empty($registeredCar)) {
                // The student has already registered a vehicle
                $conn->rollback();
                echo "<script>alert('You have already registered a vehicle. Please go to the personal details page if you wish to edit or delete your vehicle');</script>";
            } else {
                // The student has not registered a vehicle, proceed with the registration
                $insertVehicleSql = "INSERT INTO vehicles (numberPlate, make, model, color, ownerID) VALUES ('$numberPlate', '$carMake', '$carModel', '$carColor', '$studentID')";

                if ($conn->query($insertVehicleSql) === TRUE) {
                    // Vehicle data inserted successfully, now update the student data in the students table
                    $updateStudentSql = "UPDATE students SET registeredCar = '$numberPlate', isDisabled = '$isDisabled' WHERE student_id = '$studentID'";

                    if ($conn->query($updateStudentSql) === TRUE) {
                        // Commit the transaction
                        $conn->commit();

                        // Registration successful
                        // Redirect to the login page or wherever you want to redirect after successful registration
                        echo "<script type ='text/JavaScript'>"; echo "alert('Registered successfully')"; echo "</script>"; 
                        header("Location: form.php");
                        exit();
                    } else {
                        // Error updating student data
                        $conn->rollback();
                        $errors[] = "Error updating student data: " . $conn->error;
                    }
                } else {
                    // Error inserting vehicle data
                    $conn->rollback();
                    $errors[] = "Error inserting vehicle data: " . $conn->error;
                }
            }
        } else {
            // Error fetching student data
            $errors[] = "Error fetching student data: " . $conn->error;
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="form.css">
</head>
<body>
    <header>
        <nav class="nav1">
            <img src="pics/625-6259602_strathmore-university-hd-png-download-removebg-preview.png" alt="">
            <h1>Student Vehicle Registration Form</h1>
            <a href="guidelines.html">Registration Guidelines</a>
            <a href="form.php" class="active">Registration Form</a>
            <a href="profile.php">Personal Details</a>
        </nav>
    </header>
    <div class="warn">
        <p style = "color: red;">Please make sure to read the registration guidelines before you fill in the form.</p>
        <p style = "color: red;">Ensure all the fields have been filled in.</p>
    </div>

    <form id="registrationForm" method="post" onsubmit="return validateForm()">
        <!-- Vehicle Details Section -->
        <div class="rect2">
            <p>Vehicle Details</p>
        </div>
        <div class="vehicle">
            <label for="numberPlate">Number Plate*</label>
            <input type="text" required id="numberPlate" name="numberPlate">
            <label for="carMake">Make*</label>
            <input type="text" required id="carMake" name="carMake">
            <label for="carModel">Model*</label>
            <input type="text" required id="carModel" name="carModel">
            <label for="carColor">Color*</label>
            <input type="text" required id="carColor" name="carColor">
            <label for="isDisabled">Are you disabled?*</label>
            <select id="isDisabled" name="isDisabled" required>
                <option value="">Select an option</option>
                <option value="true">Yes</option>
                <option value="false">No</option>
            </select>
        </div>
        <div class="ins">
            <input type="submit" value="Submit">
            <input type="reset" value="Reset">
        </div>
    </form>

    <script>
        function validateForm() {
            // Validate number plate format (e.g., KAA111A)
            var numberPlateInput = document.getElementById("numberPlate");
            var numberPlateValue = numberPlateInput.value.trim();
            var numberPlatePattern = /^[A-Z]{3}\d{3}[A-Z]$/; // Three letters, three digits, one letter

            if (!numberPlatePattern.test(numberPlateValue)) {
                alert("Invalid number plate format. Please use a format like KAA111A.");
                numberPlateInput.focus();
                return false;
            }

            // Additional validation logic for other fields can be added here

            return true; // Form is valid, proceed with submission
        }
    </script>
</body>
</html>

