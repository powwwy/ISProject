<?php
include 'connect.php';

$student_id = $_GET['updateid'];
$sql = "SELECT * FROM students WHERE student_id = $student_id";

$result = mysqli_query($conn, $sql);
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $access = $row['access_status'];
    $name = $row['name'];
} else {
    echo "not successful";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST["name"];
    $access = isset($_POST["access"]) ? $_POST["access"] : $access; // Use the submitted value if available, else use the current value

    // Use prepared statement to prevent SQL injection
    $sql = "UPDATE students SET access_status = ? WHERE student_id = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ii", $access, $student_id);

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            mysqli_close($conn);
            if ($access == 1) {
                echo '<script>alert("Access has been granted to the student.");</script>';
            } else {
                echo '<script>alert("Access has been denied to the student.");</script>';
            }
            header('Location: admin.php');
        } else {
            echo "Update failed: " . mysqli_error($conn);
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
</head>
<body>
    <h1>Update Access for Student: <?php echo $student_id . " " . $name; ?></h1>
    <div class = "radios">
    <form action="" method="post">
        <label for="access_granted">Access Denied</label>
        <input type="radio" name="access" value="1" <?php echo $access == 1 ? 'checked' : ''; ?>>
        
        <label for="access_denied">Access Granted</label>
        <input type="radio" name="access" value="0" <?php echo $access == 0 ? 'checked' : ''; ?>>
        
        <input type="submit" name="submit" value="Update">
    </form>
</div>
</body>
</html>
