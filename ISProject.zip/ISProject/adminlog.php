<?php
session_start();
include 'connect.php';

// Admin Login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $admin_id = $_POST["AdminID"];
    $password = $_POST["passWord"];

    // Validate form fields
    $errors = array();

    if (empty($admin_id)) {
        $errors[] = "Admin ID is required";
    }

    if (empty($password)) {
        $errors[] = "Password is required";
    }

    if (empty($errors)) {
        // Check if the user exists in the database
        $sql = "SELECT * FROM administrator WHERE admin_id = '$admin_id'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $storedPassword = $row["password"];
            
            // Verify the entered password against the stored hashed password
            if (password_verify($password, $storedPassword)) {
                $_SESSION["AdminID"] = $row["admin_id"];
                header("Location: admin.php");
                exit();
            } else {
                // Password is incorrect
                $errors[] = "Invalid Admin ID or password";
            }
        } else {
            // User does not exist
            $errors[] = "Invalid Admin ID or password";
        }
    }
}

// Admin Signup
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signup"])) {
    $admin_id = $_POST["adminID"];
    $admin_email = $_POST["adminEmail"];
    $admin_name = $_POST["adminName"];
    $password = $_POST["adminPass"];

    // Validate form fields
    $errors = array();

    if (empty($admin_id)) {
        $errors[] = "Admin ID is required";
    }

    if (empty($password)) {
        $errors[] = "Password is required";
    }
    if (empty($admin_name)) {
        $errors[] = "Name is required";
    }
    if (empty($admin_email)) {
        $errors[] = "Email is required";
    }

    if (empty($errors)) {
        // Hash the password before inserting it into the database
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert new admin into the database
        $insert_sql = "INSERT INTO administrator (admin_id, password, name, email)
            VALUES ('$admin_id', '$hashedPassword', '$admin_name', '$admin_email')";

        if ($conn->query($insert_sql) === TRUE) {
            // Registration successful
            $_SESSION['success_message'] = "Admin Registered Successfully";

            // Redirect to the login page
            header("Location: adminlog.php");
            exit();
        } else {
            // Error inserting admin
            $errors[] = "Error registering admin: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <link rel="stylesheet" href="adminlog.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@500&display=swap" rel="stylesheet">
</head>
<body>
  <div class="heads">
    <img src="pics/logostrathmore.png" alt="">
    <h1 id="formTitle" class="form__title">Admin Login</h1>
    <h1></h1>
    <h1></h1>
  </div>
  <div class="container">
    <!-- Login Form -->
    <form class="form" id="login" action="adminlog.php" method="post">
      <h1>Login</h1>
  
      <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"]) && !empty($errors)) : ?>
        <div class="form__message form__message--error">
          <?php foreach ($errors as $error) : ?>
            <p><?php echo $error; ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>  
      
      <div class="form__input-group">
        <input type="text" class="form__input" autofocus placeholder="Admin ID" name="AdminID">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="password" class="form__input" autofocus placeholder="Password" name="passWord">
        <div class="form__input-error-message"></div>
      </div>
      <button class="form__button" type="submit" name="login">Continue</button>
      <p class="form__text">
        <a class="form__link" href="#" id="linkCreateAccount">Don't have an account? Create account</a>
      </p>
    </form>

    <!-- Signup Form -->
    <form class="form form--hidden" id="createAccount" action="adminlog.php" method="post">
      <h1 class="form__title">Create Account</h1>
      
      <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signup"]) && !empty($errors)) : ?>
        <div class="form__message form__message--error">
          <?php foreach ($errors as $error) : ?>
            <p><?php echo $error; ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
  
      <div class="form__input-group">
        <input type="text" id="adminID" class="form__input" autofocus placeholder="Admin ID" name="adminID">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="text" id="adminName" class="form__input" autofocus placeholder="Name" name="adminName">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="email" id="adminEmail" class="form__input" autofocus placeholder="Email" name="adminEmail">
        <div class="form__input-error-message"></div>
      </div>
      
      <div class="form__input-group">
        <input type="password" class="form__input" autofocus placeholder="Password" name="adminPass">
        <div class="form__input-error-message"></div>
      </div>
      <button class="form__button" type="submit" name="signup">Continue</button>
      <p class="form__text">
        <a class="form__link" href="./" id="linkLogin">Already have an account? Sign in</a>
      </p>
    </form>
  </div>
  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const loginForm = document.querySelector("#login");
      const createAccountForm = document.querySelector("#createAccount");
      const formTitle = document.querySelector("#formTitle");
    
      document.querySelector("#linkCreateAccount").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.add("form--hidden");
        createAccountForm.classList.remove("form--hidden");
        formTitle.textContent = "Sign up ";
      });
    
      document.querySelector("#linkLogin").addEventListener("click", e => {
        e.preventDefault();
        createAccountForm.classList.add("form--hidden");
        loginForm.classList.remove("form--hidden");
        formTitle.textContent = "Login ";
      });
    });
  </script>
</body>
</html>
