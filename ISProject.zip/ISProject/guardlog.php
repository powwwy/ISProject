<?php
session_start();
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {

    $guard_id = $_POST["guardID"];
    $password = $_POST["passWord"];

    // Validate form fields
    $errors = array();

    if (empty($guard_id)) {
        $errors[] = "Guard ID is required";
    }

    if (empty($password)) {
        $errors[] = "Password is required";
    }

    if (empty($errors)) {
        // Check if the user exists in the database
        $sql = "SELECT * FROM security WHERE guard_id = '$guard_id'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $storedPassword = $row["password"];
            
            // Verify the entered password against the stored hashed password
            if (password_verify($password, $storedPassword)) {
                $_SESSION["guardID"] = $row["guard_id"];
                header("Location: guard.php");
                exit();
            } else {
                // Password is incorrect
                $errors[] = "Invalid guard ID or password";
            }
        } else {
            // User does not exist
            $errors[] = "Invalid guard ID or password";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Guard Login</title>
  <link rel="stylesheet" href="guard.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@500&display=swap" rel="stylesheet">
</head>
<body>
  <div class="heads">
    <img src="pics/logostrathmore.png" alt="">
    <h1 id="formTitle" class="form__title">Security Login</h1>
    <h1></h1>
    <h1></h1>
  </div>
  <div class="container">
    <form class="form" id="signin" action="guardlog.php" method="post">
      <h1 >Login</h1>
  
      <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"]) && !empty($errors)) : ?>
        <div class="form__message form__message--error">
          <?php foreach ($errors as $error) : ?>
            <p><?php echo $error; ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>  
      
      <div class="form__input-group">
        <input type="text" class="form__input" autofocus placeholder="Guard ID" name="guardID">
        <div class="form__input-error-message"></div>
      </div>
      <div class="form__input-group">
        <input type="password" class="form__input" autofocus placeholder="Password" name="passWord">
        <div class="form__input-error-message"></div>
      </div>
      <button class="form__button" type="submit" name="login">Continue</button>
    </form>