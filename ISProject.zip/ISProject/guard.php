<?php
session_start();
include 'connect.php'; 

// Check if the guard is logged in (You may modify this as needed)
if (!isset($_SESSION['guardID'])) {
  header("Location: guardlog.php");
  exit();
}

// Handle the "Give warning" button click
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['giveWarning'])) {
  $studentID = $_POST['studentID']; // Get the student ID from the hidden input field
  $warnings = $_POST['warnings']; // Get the current number of warnings

  // Increment the warnings count
  $newWarnings = $warnings + 1;

  // Prepare and execute the query to update the warnings in the database
  $sqlUpdate = "UPDATE students SET warnings = '$newWarnings' WHERE student_id = '$studentID'";
  $resultUpdate = mysqli_query($conn, $sqlUpdate);

  if ($resultUpdate) {
    // Update successful
    header("Location: guard.php"); // Redirect back to the guard page
    exit();
  } else {
    // Error occurred while updating the warnings
    // You may add error handling here as needed
    echo "Error: " . mysqli_error($conn);
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="guard.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Security</title>
</head>
<body>
<header>
    <nav class="heads2">
      <img src="pics/625-6259602_strathmore-university-hd-png-download-removebg-preview.png" alt="">
      <h1>Verify Vehicles</h1>
      <a href="report.php">Report Student</a>
      <a href="secout.php">Logout</a>
    </nav>
</header> 
    </nav>
</header> 

<div class="search-bar">
    <input type="text" id="searchInput" placeholder="Search by Student ID">
  </div>
  

<table class="table">
  <thead>
    <tr>
      <th scope="col"><strong>Student ID</strong></th>
      <th scope="col"><strong>Name</strong></th>
      <th scope="col"><strong>Number Plate</strong></th>
      <th scope="col"><strong>Make</strong></th>
      <th scope="col"><strong>Model</strong></th>
      <th scope="col"><strong>Color</strong></th>
      <th scope="col"><strong>Warnings</strong></th>
      <th scope="col"><strong>Access Status</strong></th>
      <th scope="col"><strong>Give warning</strong></th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sql = "SELECT s.student_id, s.name, v.numberPlate, v.make, v.model, v.color, s.warnings, s.access_status
    FROM students s
    INNER JOIN vehicles v ON s.student_id = v.ownerID";
    $result = mysqli_query($conn, $sql);
    if ($result) {
      if (mysqli_num_rows($result) > 0) {
        // Records found, display the table
        while ($row = mysqli_fetch_assoc($result)) {
          $id = $row['student_id'];
          $car = $row['numberPlate'];
          $name = $row['name'];
          $make = $row['make'];
          $model = $row['model'];
          $color= $row['color'];
          $warnings= $row['warnings'];
          $access = $row['access_status'];

          // Display "Granted" for access_status = 1, and "Denied" for access_status = 0
          $accessStatusDisplay = ($access == 0) ? "Granted" : "Denied";

          echo "<tr>
                  <th scope='row'>$id</th>
                  <td>$name</td>
                  <td>$car</td>
                  <td>$make</td>
                  <td>$model</td>
                  <td>$color</td>
                  <td>$warnings</td>
                  <td>Access $accessStatusDisplay</td>
                  <td>
                    <form action='guard.php' method='post'>
                      <input type='hidden' name='studentID' value='$id'>
                      <input type='hidden' name='warnings' value='$warnings'>
                      <button type='submit' name='giveWarning'>Give warning</button>
                    </form>
                  </td>
                </tr>";
        }
      } else {
        // No records found, display "Unregistered" in all fields
        echo "<tr>
                <td colspan='9'>Unregistered</td>
              </tr>";
      }
    }
    ?>
  </tbody>
</table>
<script>
    // Function to filter the student IDs based on the search input
    function filterStudents() {
      const searchInputValue = document.getElementById("searchInput").value.trim().toLowerCase();
      const studentRows = document.querySelectorAll(".table tbody tr");

      studentRows.forEach(row => {
        const studentId = row.querySelector("th").textContent.toLowerCase();
        if (studentId.includes(searchInputValue)) {
          row.style.display = "table-row";
        } else {
          row.style.display = "none";
        }
      });
    }
    // Event listener for the search input
    document.getElementById("searchInput").addEventListener("input", filterStudents);
  </script>
</body>
</html>
